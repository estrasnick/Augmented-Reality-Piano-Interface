﻿# Alphatab.Wpf.Gdi

This sample uses GDI+ as drawing engine and uses WPF to actually display the rendered image. 