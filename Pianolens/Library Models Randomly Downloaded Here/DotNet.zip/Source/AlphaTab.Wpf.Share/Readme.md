﻿# Alphatab.Wpf.Share

This project contains shared classes for all WPF sample projects. 
