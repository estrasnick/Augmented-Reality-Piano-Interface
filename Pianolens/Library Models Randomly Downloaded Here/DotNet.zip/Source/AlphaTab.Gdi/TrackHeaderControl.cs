﻿using System.Drawing;
using System.Windows.Forms;
using alphatab.model;

namespace AlphaTab.Gdi
{
    public partial class TrackHeaderControl : UserControl
    {
        public TrackHeaderControl()
        {
            InitializeComponent();
        }
    }
}
