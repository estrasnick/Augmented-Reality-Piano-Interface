using haxe.root;
#pragma warning disable 109, 114, 219, 429, 168, 162
namespace haxe
{
	public  class Int64 
	{
		public    Int64()
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
	}
}


