using haxe.root;
namespace alphatab.platform.svg
{
	public enum SupportedFonts
	{
		TimesNewRoman, Arial
	}
}


