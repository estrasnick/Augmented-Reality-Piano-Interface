using haxe.root;
namespace alphatab.platform.model
{
	public enum TextAlign
	{
		Left, Center, Right
	}
}


