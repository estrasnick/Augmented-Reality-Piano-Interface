using haxe.root;
namespace alphatab.importer
{
	public enum AlphaTexSymbols
	{
		No, Eof, Number, DoubleDot, Dot, String, Tuning, LParensis, RParensis, LBrace, RBrace, Pipe, MetaCommand, Multiply
	}
}


