using haxe.root;
namespace alphatab.model
{
	public enum AutomationType
	{
		Tempo, Volume, Instrument, Balance
	}
}


