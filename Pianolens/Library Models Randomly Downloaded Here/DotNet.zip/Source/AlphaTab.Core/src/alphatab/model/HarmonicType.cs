using haxe.root;
namespace alphatab.model
{
	public enum HarmonicType
	{
		None, Natural, Artificial, Pinch, Tap, Semi, Feedback
	}
}


