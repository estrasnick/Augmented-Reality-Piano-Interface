using haxe.root;
namespace alphatab.model
{
	public enum Duration
	{
		Whole, Half, Quarter, Eighth, Sixteenth, ThirtySecond, SixtyFourth
	}
}


