using haxe.root;
namespace alphatab.model
{
	public enum PickStrokeType
	{
		None, Up, Down
	}
}


