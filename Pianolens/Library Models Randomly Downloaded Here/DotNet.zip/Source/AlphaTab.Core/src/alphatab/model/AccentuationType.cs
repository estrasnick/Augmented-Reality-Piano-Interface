using haxe.root;
namespace alphatab.model
{
	public enum AccentuationType
	{
		None, Normal, Heavy
	}
}


