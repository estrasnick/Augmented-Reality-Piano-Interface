using haxe.root;
namespace alphatab.model
{
	public enum DynamicValue
	{
		PPP, PP, P, MP, MF, F, FF, FFF
	}
}


