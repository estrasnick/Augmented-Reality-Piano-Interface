using haxe.root;
namespace alphatab.model
{
	public enum Clef
	{
		Neutral, C3, C4, F4, G2
	}
}


