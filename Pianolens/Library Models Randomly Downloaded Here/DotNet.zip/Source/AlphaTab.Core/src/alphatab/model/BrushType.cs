using haxe.root;
namespace alphatab.model
{
	public enum BrushType
	{
		None, BrushUp, BrushDown, ArpeggioUp, ArpeggioDown
	}
}


