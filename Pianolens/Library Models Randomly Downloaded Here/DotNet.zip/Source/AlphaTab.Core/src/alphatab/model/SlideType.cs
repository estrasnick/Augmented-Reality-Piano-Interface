using haxe.root;
namespace alphatab.model
{
	public enum SlideType
	{
		None, Shift, Legato, IntoFromBelow, IntoFromAbove, OutUp, OutDown
	}
}


