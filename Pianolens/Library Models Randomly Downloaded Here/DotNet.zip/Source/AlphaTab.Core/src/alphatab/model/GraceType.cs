using haxe.root;
namespace alphatab.model
{
	public enum GraceType
	{
		None, OnBeat, BeforeBeat
	}
}


