using haxe.root;
namespace alphatab.model
{
	public enum AccidentalType
	{
		None, Natural, Sharp, Flat
	}
}


