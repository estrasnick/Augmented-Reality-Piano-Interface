using haxe.root;
#pragma warning disable 109, 114, 219, 429, 168, 162
namespace alphatab.rendering.glyphs
{
	public  interface IMultiBeatEffectGlyph : global::haxe.lang.IHxObject 
	{
		   void expandedTo(global::alphatab.model.Beat beat);
		
	}
}


