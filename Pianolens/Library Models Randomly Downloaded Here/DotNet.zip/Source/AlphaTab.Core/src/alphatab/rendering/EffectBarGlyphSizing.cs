using haxe.root;
namespace alphatab.rendering
{
	public enum EffectBarGlyphSizing
	{
		SinglePreBeatOnly, SinglePreBeatToOnBeat, SinglePreBeatToPostBeat, SingleOnBeatOnly, SingleOnBeatToPostBeat, SinglePostBeatOnly, GroupedPreBeatOnly, GroupedPreBeatToOnBeat, GroupedPreBeatToPostBeat, GroupedOnBeatOnly, GroupedOnBeatToPostBeat, GroupedPostBeatOnly
	}
}


