using haxe.root;
#pragma warning disable 109, 114, 219, 429, 168, 162
namespace alphatab.rendering.glyphs
{
	public  interface ISupportsFinalize : global::haxe.lang.IHxObject 
	{
		   void finalizeGlyph(global::alphatab.rendering.layout.ScoreLayout layout);
		
	}
}


