using haxe.root;
namespace alphatab.rendering.glyphs
{
	public enum CrescendoType
	{
		None, Crescendo, Decrescendo
	}
}


