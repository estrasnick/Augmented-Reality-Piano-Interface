using haxe.root;
#pragma warning disable 109, 114, 219, 429, 168, 162
namespace alphatab
{
	public class EntryPoint__Main
	{
		public static void Main()
		{
			global::cs.Boot.init();
			global::alphatab.Main.main();
		}
	}
	public  class Main : global::haxe.lang.HxObject 
	{
		public    Main(global::haxe.lang.EmptyObject empty)
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public    Main()
		{
			unchecked 
			{
				global::alphatab.Main.__hx_ctor_alphatab_Main(this);
			}
		}
		
		
		public static   void __hx_ctor_alphatab_Main(global::alphatab.Main __temp_me48)
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public static   void main()
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public static  new object __hx_createEmpty()
		{
			unchecked 
			{
				return new global::alphatab.Main(((global::haxe.lang.EmptyObject) (global::haxe.lang.EmptyObject.EMPTY) ));
			}
		}
		
		
		public static  new object __hx_create(global::haxe.root.Array arr)
		{
			unchecked 
			{
				return new global::alphatab.Main();
			}
		}
		
		
	}
}


