using haxe.root;
#pragma warning disable 109, 114, 219, 429, 168, 162
namespace haxe.lang
{
	public  class FieldLookup : global::haxe.lang.HxObject 
	{
		public    FieldLookup(global::haxe.lang.EmptyObject empty)
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public    FieldLookup()
		{
			unchecked 
			{
				global::haxe.lang.FieldLookup.__hx_ctor_haxe_lang_FieldLookup(this);
			}
		}
		
		
		public static   void __hx_ctor_haxe_lang_FieldLookup(global::haxe.lang.FieldLookup __temp_me277)
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public static  global::haxe.root.Array<int> fieldIds = new global::haxe.root.Array<int>(new int[]{98, 102, 109, 112, 120, 121, 21300, 23515, 26203, 322674, 714892, 909570, 1707673, 1821933, 4745537, 4746436, 4750021, 4846113, 4895187, 4947578, 4949376, 5047484, 5144726, 5393365, 5442204, 5594513, 5594516, 5741474, 5745024, 5745252, 5790293, 5790298, 5790307, 7816481, 10018423, 20078838, 21532461, 26903797, 29588086, 30278530, 38537191, 42740551, 46352402, 46374763, 46422045, 46423831, 46594619, 49465911, 52644165, 55629992, 59156322, 59370440, 60289868, 62672272, 67315271, 67859554, 67860431, 73353859, 76061764, 77654503, 84315527, 84881289, 86600534, 87367608, 88562355, 89811960, 90098500, 91153158, 98812439, 100490692, 105656838, 108520940, 109002835, 115063718, 120199547, 120694166, 127983386, 131841789, 134035422, 137661698, 139280181, 142301684, 152554969, 152811322, 155491985, 158873116, 159136996, 161606508, 166341986, 169770535, 173029674, 173283864, 175582839, 178206195, 179047623, 179703352, 186102306, 188501856, 188579043, 193577032, 197276318, 199127676, 199163160, 202704573, 204643997, 207609411, 223048071, 223988822, 226931207, 227602139, 233406162, 235590296, 236164353, 238619611, 243225909, 248321755, 249568768, 250834870, 252174360, 253080294, 258089931, 259814420, 259830954, 267491432, 268153213, 268685047, 271087020, 272307608, 274206003, 274387109, 286784413, 288167040, 288368849, 288666552, 288700050, 291053381, 291106525, 291454571, 294620923, 295397041, 299360643, 302437836, 302979532, 305429260, 307367471, 307761913, 311465992, 316994587, 321635438, 328878574, 329786712, 336701854, 337206185, 337667453, 338202835, 342184423, 344334046, 344854356, 347982241, 351513182, 355457055, 357418928, 363853384, 366738048, 369425836, 371166859, 371286681, 375895439, 379947302, 381239946, 391262694, 400509660, 401197594, 401348099, 407283053, 411825530, 411948561, 414021780, 415081458, 416595323, 420980214, 422637862, 430913175, 432148711, 433403721, 438023882, 438479229, 443796344, 447718479, 448039670, 448361819, 452356799, 452737314, 455632317, 457424429, 462066548, 464659330, 465864860, 468906571, 480756972, 481612700, 483396326, 484418037, 485089498, 485419969, 486630117, 490745573, 491088124, 493819893, 498486927, 500240383, 500560319, 501039929, 504792271, 507444810, 507631656, 516081608, 517361783, 519815730, 520590566, 520665567, 523068202, 524783129, 528048154, 529989321, 530877726, 530960102, 533388353, 533940217, 539976515, 540881986, 542823803, 544876244, 550203803, 553915593, 559254965, 561297662, 562828079, 572707279, 574024391, 589751150, 589796196, 596483356, 610723709, 617369845, 624508576, 625209805, 628441485, 632389428, 632903889, 638277820, 640252688, 649684599, 650430015, 655539612, 662803912, 664175990, 667795229, 672263473, 673875012, 674558384, 676522989, 680886982, 695082016, 698229495, 700148106, 702377529, 705429760, 706091227, 708429200, 720573327, 724954170, 726713937, 742854407, 746467688, 768599606, 784731061, 792673520, 794258599, 798803052, 803091205, 804986685, 810640957, 822594234, 825135865, 825311129, 826045953, 831576528, 834174833, 841501494, 848728090, 850086945, 852203651, 853263683, 854748907, 855239132, 860647805, 860674150, 867499896, 875656696, 877939665, 880319888, 887070651, 895305313, 897232691, 897413587, 900561264, 906525346, 907617685, 913255283, 914740105, 918754500, 922037898, 922671056, 930488813, 939528350, 943871192, 943928435, 946786476, 949687761, 956261828, 958687736, 961082055, 961570460, 966720823, 972861882, 972910470, 973409099, 974309580, 974358180, 978278827, 980448698, 983703593, 989275570, 990712073, 995006396, 997235974, 1007125841, 1008410485, 1008896224, 1015205801, 1015335773, 1016047850, 1020198193, 1027615804, 1028568990, 1029017651, 1035342189, 1041537810, 1056509822, 1057738399, 1058404052, 1058459579, 1059101146, 1059199721, 1059254117, 1059398626, 1064531265, 1066332547, 1067353468, 1071652316, 1073796440, 1077438631, 1077515974, 1079503181, 1083160452, 1085707415, 1086991092, 1090814424, 1091626816, 1091821942, 1092171829, 1097521840, 1100006280, 1102715933, 1103232509, 1103260490, 1103412149, 1105941737, 1111114639, 1113806378, 1114502602, 1114503266, 1115413384, 1116545170, 1116891722, 1118815795, 1131575193, 1134013342, 1136329018, 1136381571, 1136827579, 1147273963, 1147273964, 1147273969, 1147273980, 1147430701, 1158278511, 1164415160, 1165831048, 1169594568, 1169898256, 1170095196, 1178843300, 1179254087, 1179290640, 1181037546, 1184080679, 1189501348, 1189501362, 1191633396, 1191702626, 1195604294, 1197946359, 1202919412, 1203214886, 1204816148, 1208461889, 1213952397, 1214305123, 1214452573, 1214453688, 1217412040, 1219967251, 1220162377, 1224700491, 1224901875, 1225225327, 1225398258, 1228566710, 1231600925, 1234579992, 1236017934, 1237368860, 1238729570, 1238832007, 1239076724, 1242376748, 1244852144, 1246287078, 1247572323, 1247576961, 1247875546, 1247983110, 1248668917, 1249074019, 1250598502, 1263850777, 1269254998, 1269255460, 1270934932, 1272889054, 1273099754, 1280549057, 1280644735, 1280692680, 1280845662, 1282943179, 1286276959, 1286394604, 1290487350, 1291439277, 1291633955, 1292432058, 1293078667, 1308691246, 1309344294, 1310257562, 1313416818, 1315213161, 1321811028, 1322144784, 1324324830, 1327292751, 1329360815, 1331941076, 1332371469, 1334722860, 1336074296, 1336873467, 1339914850, 1341358681, 1342455131, 1345344942, 1349150671, 1349863027, 1350630187, 1352786672, 1353738693, 1361216012, 1365104735, 1366752649, 1368126571, 1368249255, 1374732481, 1377207970, 1381203243, 1381630732, 1382488090, 1390832121, 1390889528, 1392437444, 1395480923, 1395555037, 1401458574, 1401610495, 1402094524, 1405029166, 1407294686, 1408430471, 1420285052, 1424663982, 1427060704, 1428159260, 1437545710, 1443721744, 1449966432, 1450069007, 1451063140, 1454772953, 1456144384, 1458228086, 1464822705, 1475155156, 1485210388, 1485888097, 1486298884, 1486936852, 1487265300, 1488498346, 1493167041, 1494774083, 1495460989, 1496985272, 1502232391, 1505576615, 1509814314, 1511295011, 1511801246, 1513270538, 1517203539, 1521866836, 1522424353, 1524598821, 1528640775, 1529130600, 1530357760, 1531430232, 1532710347, 1534092457, 1537341680, 1537678743, 1537812987, 1542788809, 1543482992, 1546764295, 1547539107, 1548009239, 1549276146, 1554593313, 1559296472, 1560739056, 1563638712, 1565120129, 1570770229, 1574438373, 1579021529, 1580906429, 1581836661, 1582764861, 1585596047, 1590545018, 1590601430, 1594575703, 1598475321, 1599285722, 1599970376, 1602529300, 1602913855, 1606329826, 1607275438, 1614780307, 1614864450, 1617311389, 1618969487, 1620824029, 1621420777, 1623686491, 1630252697, 1636857419, 1639293562, 1640216304, 1643347241, 1648581351, 1648762369, 1648849563, 1650208238, 1655812875, 1658175220, 1658522974, 1658522975, 1666948180, 1676981435, 1683565844, 1684793203, 1686416180, 1688947841, 1691905151, 1692871406, 1692978337, 1694779088, 1695797088, 1695828234, 1697073479, 1698949528, 1704429917, 1705131637, 1705629508, 1707881443, 1708501536, 1713359061, 1715971153, 1719485384, 1723548982, 1723805383, 1724402127, 1725549749, 1726550773, 1726950318, 1727523034, 1728502613, 1728902453, 1730312684, 1734479962, 1734539814, 1735084935, 1737429752, 1739960653, 1744813180, 1746477760, 1751303026, 1751332267, 1753785726, 1754116104, 1760390271, 1762181558, 1762376684, 1762379567, 1762533406, 1762579836, 1762877088, 1763375486, 1764199192, 1772779934, 1774118697, 1776938941, 1778087414, 1780601078, 1790892546, 1792102594, 1796997604, 1801219961, 1802708962, 1805014325, 1806698356, 1811871594, 1812105259, 1818949592, 1822443151, 1824081223, 1825584277, 1826654217, 1827465669, 1828730163, 1829781184, 1830310359, 1832144217, 1832883877, 1833015931, 1834786111, 1836776262, 1837892969, 1840455391, 1840474385, 1842287352, 1846265040, 1848890263, 1853446518, 1858026222, 1861630229, 1873734400, 1881669935, 1891834246, 1895255233, 1895953000, 1905696925, 1906311879, 1906986366, 1907509625, 1914101345, 1915412854, 1916009602, 1921156710, 1923205974, 1932118984, 1932180489, 1936847723, 1940366524, 1942741029, 1945717380, 1947978492, 1948581205, 1952851773, 1955004862, 1955029599, 1958090187, 1958787731, 1958899313, 1967318617, 1967561873, 1969111172, 1970316280, 1970565641, 1981972957, 1984794979, 1987833219, 1988514268, 1992237101, 1993439662, 1998021559, 1999551132, 2000963577, 2001890127, 2002104775, 2020590808, 2022294396, 2022543392, 2025055113, 2026656845, 2026819210, 2027205955, 2027516754, 2028270691, 2029227650, 2035221739, 2048392659, 2056329483, 2069681853, 2075993520, 2075993521, 2079799002, 2081384188, 2082157521, 2082335259, 2082548183, 2082663554, 2083451114, 2084789794, 2089043906, 2094598290, 2094661564, 2097124632, 2102469687, 2104008174, 2105889885, 2106138990, 2111645508, 2112234752, 2124583197, 2127021138, 2127207408, 2132043430, 2137308320, 2141318064, 2141318065});
		
		public static  global::haxe.root.Array<object> fields = new global::haxe.root.Array<object>(new object[]{"b", "f", "m", "p", "x", "y", "_s", "id", "up", "_style", "_text", "_ties", "_type", "isGlobal", "__a", "_ch", "_sy", "add", "bar", "cmd", "cur", "eof", "get", "len", "map", "pop", "pos", "set", "sub", "svg", "tab", "tag", "tap", "primaryChannel", "files", "_beamHelperLookup", "addGraceBeat", "createNoteGlyphs", "deltaFretToHarmonicValue", "_noteString", "height", "flags", "quadraticCurveTo", "readAll", "readBar", "readBit", "timeSignatureDenominator", "_maxNote", "match", "isTieDestination", "slideTarget", "parseTuning", "firstChild", "readStringIntByte", "hasBottomOverflow", "start", "stave", "isPercussion", "remove", "graceFont", "_firstStaveInAccolade", "registerStaveTop", "render", "filter", "addNote", "subTitle", "getOrCreateVoiceContainer", "trillValue", "readBlock", "staves", "staveTop", "beatEffects", "finish", "paintBeams", "invalidate", "setFileFilter", "previousMasterBar", "createVoiceGlyphs", "closings", "masterBars", "tuning", "resize", "isHammerPullDestination", "readNoteEffects", "setFont", "_tempo", "matched", "tuplet", "paintScoreInfo", "_rhythmById", "recreatePen", "maxDuration", "registerStaveBottom", "_groups", "readString", "barMeta", "downLineX", "getStemSize", "settings", "createNewGlyph", "readBitsReversed", "readVoice", "getBeatLineX", "_automations", "readUncompressedBlock", "isEmpty", "_currentLayoutMode", "_tappedNotes", "getString", "tempo", "graceType", "getGlyphOverflow", "finalizeRenderer", "_crescendo", "readBytes", "getMasterBar", "toRgbaString", "parseGeneralMidi", "readInt32", "isStaccato", "addGlyph", "_higherBits", "addTrack", "_number", "barRenderers", "getSizingMode", "getBeatX", "title", "hasBend", "music", "shouldCreateGlyph", "stream", "string", "stroke", "tempoAutomation", "_lastCmd", "getLineOffset", "getLastBarIndex", "getValue", "GetHashCode", "setSize", "_track", "methodName", "createStaveGroup", "setStyle", "renderingResources", "_position", "readMasterBar", "beginPath", "iterator", "_registeredAccidentals", "parseDiagramCollection", "toSvg", "closePath", "_lyrics", "subTitleFont", "nextMasterBar", "duration", "_preBeatGlyphs", "checkBeat", "_lastCreateInfo", "getBottomPadding", "getOnNoteSize", "_group", "glyph", "track", "_textAlign", "_fontSize", "readChord", "canExpand", "get_nodeValue", "totlen", "setCanvas", "_noteById", "hasNext", "_tupletHelpers", "peekChar", "setPreNoteSize", "getTopPadding", "paintBeamHelper", "isRepeatEnd", "newSy", "_currentBeamHelper", "shortName", "parseAutomations", "drawInfoGuide", "tupletNumerator", "getMaxWidth", "getPostBeatGlyphsStart", "createAccidentalGlyph", "_beatLineXPositions", "readNumber", "reverse", "hasTopOverflow", "readColor", "repeatCount", "_notes", "parseBeatProperties", "_lastBeat", "nOccupied", "getNoteSvg", "_glyphs", "addBeatGlyph", "checkNote", "parseScoreNode", "_voiceContainers", "getImage", "strokeRect", "getBytes", "_octave", "getNumber", "getReadBytes", "insert", "isFirstInAccolade", "_numerator", "getSvgTextAlignment", "_scaling", "getSize", "addBar", "length", "addSub", "readLyrics", "createOrResizeGlyph", "getTabY", "getDirection", "preNotes", "stringTuning", "notes", "toCssString", "_lastStaveInAccolade", "_versionNumber", "bigEndian", "_currentTupletHelper", "buildModel", "isLastInAccolade", "readStringByteLength", "applyBarSpacing", "album", "_biggestVoiceContainer", "loadBinary", "getSvg", "getTag", "balance", "writeFullBytes", "barSeperatorColor", "nextBar", "parseTrackProperty", "toDynamicValue", "lyrics", "registerMaxSizes", "automations", "writeString", "_canvas", "hasRasgueado", "createKeySignatureGlyphs", "accidentalHelper", "get_nodeName", "getSheetWidth", "_textBaseline", "applySizes", "mainGlyphColor", "createDefaultScore", "trillFret", "tuningName", "topOverflow", "numbers", "getPreBeatGlyphStart", "effectFont", "tremoloSpeed", "getWidth", "metaData", "writeTo", "volumeAutomation", "readDouble", "_lowerBits", "readBeatEffects", "applyBeatEffect", "octave", "alignGlyph", "firstElement", "isGhost", "updateWidth", "beats", "_globalTripletFeel", "recreateLayout", "getSettings", "getTopOverflow", "_nodeValue", "value", "createTimeSignatureGlyphs", "crescendo", "isTrill", "getBottomOverflow", "renderer", "readTremoloPicking", "previousBar", "accentuated", "refreshNotes", "readPageSetup", "isDoubleBar", "addVoice", "registerOverflowBottom", "_brush", "getNumberOverflow", "realValue", "isInAccolade", "setLineWidth", "onNotes", "lastCommand", "getBeatDirection", "paintTuplets", "createPreBeatGlyphs", "addBytes", "cachedIndex", "calculateHeight", "_children", "canvas", "_fileFilter", "toString", "durationPercent", "isFullBarJoin", "restGlyph", "artist", "_image", "getDigit", "getRestSvg", "_infos", "_input", "_nodeName", "minNote", "bezierCurveTo", "marker", "playbackInfo", "voice", "_hidden", "hashes", "nextToken", "finalizeStave", "defaultFileFilter", "removeRenderFinishedListener", "get_score", "beatGlyphs", "set_nodeName", "isFirstOfLine", "getSvgScale", "paint", "parse", "tablatureFont", "index", "readTracks", "_buffer", "_bar", "addChild", "_pen", "_raw", "_svg", "_val", "container", "getKeySignatureIndex", "splice", "exists", "parseTrack", "_tracksMapping", "tempoName", "bottomOverflow", "_currentPathIsEmpty", "chords", "readPlaybackInfos", "wordsFont", "bars", "beat", "blit", "hasWhammyBar", "_uniqueEffectGlyphs", "capo", "getScoreY", "clef", "copy", "parseRhythm", "_syData", "data", "dots", "down", "_maxGlyphCount", "alternateEndings", "_currentRepeatGroup", "getSvgBaseLine", "revertLastBar", "parseMasterBar", "capacity", "fill", "fret", "getA", "getB", "getG", "getR", "whammyBarPoints", "isLinear", "_lyricsTrack", "tracks", "check", "init", "chord", "_color", "_width", "_count", "join", "instrument", "_loaded", "_loader", "keys", "_isExpanded", "getBeatDurationWidth", "fullWidth", "line", "load", "concat", "createEmptyStaveGroup", "clear", "mode", "clone", "close", "applyAccidental", "parseBars", "parseBeat", "name", "next", "getResources", "note", "maxNote", "parseClef", "parseNoteProperties", "parseNotes", "readScore", "getTextAlign", "writeByte", "addPreBeatGlyph", "parseKeySignature", "readScoreInformation", "setFamily", "color", "port", "push", "width", "addPostBeatGlyph", "_trackCount", "hasTuplet", "tempoLabel", "read", "rect", "_tremoloPicking", "toStrokeValue", "parseAutomation", "size", "skip", "slap", "sort", "quicksort", "leftHandFinger", "moveTo", "getBuffer", "text", "ties", "type", "slideType", "finalizeGlyph", "readFullBytes", "tupletDenominator", "vals", "words", "brushType", "_circleSize", "timeSignatureNumerator", "getDigitWidth", "secondaryChannel", "paintScore", "getAutomation", "paintBackground", "_keySignature", "readSlide", "readVersion", "_tracksById", "notices", "tabClefFont", "getBeatGlyphsStart", "currentTokenIsNumber", "measureText", "spliceVoid", "parseNote", "isTieOrigin", "doScoreInfoLayout", "upLineX", "_playbackInfos", "_denominator", "finalizeGroup", "hasChord", "_noteLookup", "writeBytes", "staveBottom", "addNoteGlyph", "parseMasterTrackNode", "calculateBeamY", "_barsOfMasterBar", "cachedKey", "readTremoloBarEffect", "_isLast", "bendPoints", "_currentDuration", "_endingsString", "_beatById", "_postBeatGlyphs", "_curChPos", "getLayout", "trillSpeed", "_digit", "circle", "parseBar", "parseDom", "parseXml", "isNullOrEmpty", "voiceIndex", "noteLoop", "spacingChanged", "ratioPosition", "parseVoices", "setColor", "setWidth", "expandedTo", "getScale", "layout", "postNotes", "_family", "addRenderFinishedListener", "paintTupletHelper", "isSectionStart", "parseDuration", "_graphics", "decompress", "nextNoteOnSameLine", "parseBeats", "parseDiagramItem", "setOnNoteSize", "_masterBars", "_voiceById", "harmonicType", "readStringInt", "currentToken", "parseCommand", "concatNative", "markerFont", "_yScale", "_effectGlyphs", "nBuckets", "_parent", "_parsed", "copyright", "className", "createBeatDot", "set_nodeValue", "onNoteSizes", "readMixTableChange", "staveGroup", "noteNumbers", "voices", "_startNote", "section", "paintFooter", "parseTracksNode", "getOnNotesPosition", "isRepeatStart", "isBold", "isItalic", "setTextAlign", "chordId", "vibrato", "volume", "readUInt8", "getPostNotesPosition", "createTies", "_currentByte", "isDead", "offset", "isTremolo", "preNoteSizes", "isFingering", "__unsafe_get", "__unsafe_set", "_barCount", "isFull", "_factory", "lookup", "noteEffects", "setHeight", "fileName", "noteHeads", "_isFinished", "brushDuration", "recreateBrush", "raiseRenderFinished", "_currentX", "_currentY", "firstMinNote", "getStyle", "setTextBaseline", "_dynamics", "_allowNegatives", "fadeIn", "parseVoice", "_endNote", "beamingHelper", "registerOverflowTop", "isLast", "getDoubleSig", "isStandard", "drawCentered", "fileSize", "getBeatContainer", "toDynamic", "isMute", "_startSpacing", "paintBar", "_barsById", "getInteger", "isClosed", "regex", "reset", "isPalmMute", "loadBinaryAsync", "fitGroup", "getFamily", "readTrack", "readTrill", "recreateImage", "canScale", "getSvgBaseLineOffset", "titleFont", "_currentIndex", "previousBeat", "constructs", "postNoteSizes", "dynamicValue", "registerBeatLineX", "createNoteHeadGlyph", "getTextBaseline", "_currentPath", "readBars", "readBeat", "readBend", "isRest", "readBits", "readBool", "readByte", "getNoteOnString", "readStringIntUnused", "isSolo", "readArtificialHarmonic", "_attributes", "_readBytes", "_rhythmOfBeat", "readGrace", "repeatGroup", "pickStroke", "previousNoteOnSameLine", "_label", "rightHandFinger", "parseRhythms", "isLastOfLine", "bottomSpacing", "lineTo", "fillRect", "doLayout", "nextBeat", "applyGlyphSpacing", "_lineWidth", "calculateWidth", "customParams", "keySignature", "instructions", "isHammerPullOrigin", "_lyricsIndex", "params", "nextChar", "readInt8", "toHexString", "_renderFinishedListeners", "fillText", "_beamHelpers", "copyrightFont", "lastMinNote", "setPostNoteSize", "staveLineColor", "_isGrace", "_height", "readName", "readNote", "getPreNotesPosition", "barNumberColor", "shouldCreateGlyphForNote", "createBeatGlyphs", "isLetRing", "__get", "__set", "firstMaxNote", "tieOrigin", "error", "getPostNoteSize", "parseTrackProperties", "_voicesOfBar", "_minNote", "program", "setCapacity", "_beat", "_beatsOfVoice", "createNoteGlyph", "Equals", "_scale", "_score", "hammerPullOrigin", "findChildElement", "_xScale", "harmonicValue", "readMasterBars", "_data", "lineNumber", "isDigit", "readHeader", "nodeType", "_endings", "_font", "parseMasterBarsNode", "tripletFeel", "createPostBeatGlyphs", "_notesOfBeat", "_stringFormat", "updateBeamingHelper", "upperBound", "getPreNoteSize", "unshift", "_info", "scale", "get_capacity", "score", "updateCapacity", "strings", "barNumberFont", "_keys", "firstFret", "_dotOffset", "_lastControlX", "_lastControlY", "calculateDuration", "create", "_note", "openings", "_xGlyphScale", "shift", "additionalSettings", "__hx_createEmpty", "engine", "sizes", "getNoteLine", "_yGlyphScale", "addBeat", "addStave", "createStartSpacing", "topSpacing", "getClefSvg", "lastMaxNote", "getHeight", "slice", "addMasterBar", "swapAccidentals", "_size", "getNoteX", "getNoteY"});
		
		public static   int doHash(string s)
		{
			unchecked 
			{
				int acc = 0;
				{
					int _g1 = 0;
					int _g = s.Length;
					while (( _g1 < _g ))
					{
						int i = _g1++;
						acc = ( ( ( 223 * (( acc >> 1 )) ) + global::haxe.lang.StringExt.charCodeAt(s, i).@value ) << 1 );
					}
					
				}
				
				return ((int) (( ((uint) (acc) ) >> 1 )) );
			}
		}
		
		
		public static   string lookupHash(int key)
		{
			unchecked 
			{
				global::haxe.root.Array<int> ids = global::haxe.lang.FieldLookup.fieldIds;
				int min = 0;
				int max = ids.length;
				while (( min < max ))
				{
					int mid = ( min + ( (( max - min )) / 2 ) );
					int imid = ids[mid];
					if (( key < imid )) 
					{
						max = mid;
					}
					 else 
					{
						if (( key > imid )) 
						{
							min = ( mid + 1 );
						}
						 else 
						{
							return global::haxe.lang.Runtime.toString(global::haxe.lang.FieldLookup.fields[mid]);
						}
						
					}
					
				}
				
				throw global::haxe.lang.HaxeException.wrap(global::haxe.lang.Runtime.concat("Field not found for hash ", global::haxe.lang.Runtime.toString(key)));
			}
		}
		
		
		public static   int hash(string s)
		{
			unchecked 
			{
				if (string.Equals(s, default(string))) 
				{
					return 0;
				}
				
				int key = default(int);
				{
					int acc = 0;
					{
						int _g1 = 0;
						int _g = s.Length;
						while (( _g1 < _g ))
						{
							int i = _g1++;
							acc = ( ( ( 223 * (( acc >> 1 )) ) + global::haxe.lang.StringExt.charCodeAt(s, i).@value ) << 1 );
						}
						
					}
					
					key = ((int) (( ((uint) (acc) ) >> 1 )) );
				}
				
				global::haxe.root.Array<int> ids = global::haxe.lang.FieldLookup.fieldIds;
				int min = 0;
				int max = ids.length;
				while (( min < max ))
				{
					int mid = ((int) (( min + ( ((double) ((( max - min ))) ) / 2 ) )) );
					int imid = ids[mid];
					if (( key < imid )) 
					{
						max = mid;
					}
					 else 
					{
						if (( key > imid )) 
						{
							min = ( mid + 1 );
						}
						 else 
						{
							string field = global::haxe.lang.Runtime.toString(global::haxe.lang.FieldLookup.fields[mid]);
							if ( ! (string.Equals(field, s)) ) 
							{
								return  ~ (key) ;
							}
							
							return key;
						}
						
					}
					
				}
				
				ids.insert(min, key);
				global::haxe.lang.FieldLookup.fields.insert(min, s);
				return key;
			}
		}
		
		
		public static   int findHash(int hash, global::haxe.root.Array<int> hashs)
		{
			unchecked 
			{
				int min = 0;
				int max = hashs.length;
				while (( min < max ))
				{
					int mid = ( (( max + min )) / 2 );
					int imid = hashs[mid];
					if (( hash < imid )) 
					{
						max = mid;
					}
					 else 
					{
						if (( hash > imid )) 
						{
							min = ( mid + 1 );
						}
						 else 
						{
							return mid;
						}
						
					}
					
				}
				
				return  ~ (min) ;
			}
		}
		
		
		public static  new object __hx_createEmpty()
		{
			unchecked 
			{
				return new global::haxe.lang.FieldLookup(((global::haxe.lang.EmptyObject) (global::haxe.lang.EmptyObject.EMPTY) ));
			}
		}
		
		
		public static  new object __hx_create(global::haxe.root.Array arr)
		{
			unchecked 
			{
				return new global::haxe.lang.FieldLookup();
			}
		}
		
		
	}
}


