using haxe.root;
#pragma warning disable 109, 114, 219, 429, 168, 162
namespace cs
{
	public  class Boot : global::haxe.lang.HxObject 
	{
		public    Boot(global::haxe.lang.EmptyObject empty)
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public    Boot()
		{
			unchecked 
			{
				global::cs.Boot.__hx_ctor_cs_Boot(this);
			}
		}
		
		
		public static   void __hx_ctor_cs_Boot(global::cs.Boot __temp_me275)
		{
			unchecked 
			{
				{
				}
				
			}
		}
		
		
		public static   void init()
		{
			unchecked 
			{
				global::cs.Lib.applyCultureChanges();
			}
		}
		
		
		public static  new object __hx_createEmpty()
		{
			unchecked 
			{
				return new global::cs.Boot(((global::haxe.lang.EmptyObject) (global::haxe.lang.EmptyObject.EMPTY) ));
			}
		}
		
		
		public static  new object __hx_create(global::haxe.root.Array arr)
		{
			unchecked 
			{
				return new global::cs.Boot();
			}
		}
		
		
	}
}


